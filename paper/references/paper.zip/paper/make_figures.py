"""
make_figures.py -- builds the two figures used in main.tex from analyze.py output tables.

    python make_figures.py                       # uses the files in ./data (see below)
    python make_figures.py tfidf_pairwise.csv bert_pairwise.csv tfidf_conditions.csv bert_conditions.csv

Inputs (all written by analyze.py):
    table_pairwise_auc_change.csv   (Section 9)  -> pair-level change in cross-dataset AUC vs C0, with t-interval over seeds
    table_conditions.csv            (Section 1)  -> pooled cross AUC and AUC gap per condition
The files in ./data were transcribed from the analyze.py output pasted in the chat / uploaded as bert.zip. REPLACE THEM with your own
final table_*.csv files before submission (the BERT arm is being re-run with more seeds).
Cells look like '+0.053 [+0.040, +0.066] (5/5)'; the first number is the estimate, the bracket is the 95% interval.
"""
import re, sys, pathlib
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

NUM = re.compile(r"([+-]?\d+\.\d+)\s*\[\s*([+-]?\d+\.\d+)\s*,?\s*([+-]?\d+\.\d+)\s*\]")
COLS = ["S", "L", "E", "LE", "SLE", "R_E"]
LAB = {"S": "S", "L": "L", "E": "E", "LE": "L+E", "SLE": "S+L+E", "R_E": "R$_E$"}
SHORT = {"WELFake_residual": "Resid.", "McIntire": "McInt.", "ISOT": "ISOT"}
here = pathlib.Path(__file__).parent


def short(pair):
    a, b = pair.split("->")
    return f"{SHORT.get(a, a)}$\\rightarrow${SHORT.get(b, b)}"


def parse_pairwise(path):
    df = pd.read_csv(path).set_index("pair")
    est = pd.DataFrame(index=df.index, columns=COLS, dtype=float); sig = est.copy()
    for c in COLS:
        for p in df.index:
            m = NUM.search(str(df.loc[p, c])); e, lo, hi = (float(m.group(i)) for i in (1, 2, 3))
            est.loc[p, c] = e; sig.loc[p, c] = float(lo > 0 or hi < 0)       # interval excludes zero
    return est, sig


def heat(ax, est, sig, title):
    v = max(0.15, np.nanmax(np.abs(est.to_numpy())))
    im = ax.imshow(est.to_numpy(), cmap="RdBu", vmin=-v, vmax=v, aspect="auto")
    ax.set_xticks(range(len(COLS))); ax.set_xticklabels([LAB[c] for c in COLS], fontsize=8)
    ax.set_yticks(range(len(est))); ax.set_yticklabels([short(p) for p in est.index], fontsize=8)
    for i in range(len(est)):
        for j, c in enumerate(COLS):
            ax.text(j, i, f"{est.iloc[i, j]:+.3f}" + ("*" if sig.iloc[i, j] else ""), ha="center", va="center", fontsize=7,
                    fontweight="bold" if sig.iloc[i, j] else "normal")
    ax.set_title(title, fontsize=9)
    return im


def fig_heatmap(tf, bert, out):
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6))
    heat(axes[0], *parse_pairwise(tf), "TF-IDF + LR (5 seeds)")
    im = heat(axes[1], *parse_pairwise(bert), "DistilBERT (5 seeds)")
    axes[1].set_yticklabels([])
    cb = fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02); cb.set_label("change in cross-dataset AUC vs. baseline", fontsize=7)
    cb.ax.tick_params(labelsize=7)
    fig.savefig(out, bbox_inches="tight"); plt.close(fig)


def fig_gap(path, out):
    df = pd.read_csv(path).set_index("cond")
    est, lo, hi = [], [], []
    for v in df["gap_auc"]:
        m = NUM.search(v) or re.search(r"(\d\.\d+)\s*\[\s*(\d\.\d+)\s*,?\s*(\d\.\d+)\s*\]", v)
        e, l, h = (float(m.group(i)) for i in (1, 2, 3)); est.append(e); lo.append(l); hi.append(h)
    est, lo, hi = map(np.array, (est, lo, hi))
    col = ["#888" if c == "C0" else "#c84" if c.startswith("R_") else "#4a7" for c in df.index]
    fig, ax = plt.subplots(figsize=(3.4, 2.4))
    ax.bar(range(len(df)), est, yerr=[est - lo, hi - est], capsize=2, color=col)
    ax.set_xticks(range(len(df))); ax.set_xticklabels([c.replace("R_", "R$_{") + ("}$" if c.startswith("R_") else "") for c in df.index], rotation=60, fontsize=7)
    ax.set_ylabel("AUC gap (in-domain $-$ cross)", fontsize=8); ax.tick_params(axis="y", labelsize=7)
    ax.set_ylim(0.0, 0.25)
    fig.savefig(out, bbox_inches="tight"); plt.close(fig)


def fig_bert_controls(path, out):
    df = pd.read_csv(path).set_index("cond")
    pairs = [("S", "R_S"), ("E", "R_E"), ("SE", "R_SE")]
    def get(c):
        m = re.search(r"(\d\.\d+)\s*\[\s*(\d\.\d+)\s*,?\s*(\d\.\d+)\s*\]", df.loc[c, "cross_auc"]); return [float(m.group(i)) for i in (1, 2, 3)]
    fig, ax = plt.subplots(figsize=(3.4, 2.3))
    items = [("C0", "#888")] + [(c, col) for a, b in pairs for c, col in ((a, "#4a7"), (b, "#c84"))]
    for i, (c, col) in enumerate(items):
        e, lo, hi = get(c)
        ax.errorbar(i, e, yerr=[[e - lo], [hi - e]], fmt="o", color=col, capsize=2, markersize=5)
    ax.set_xticks(range(len(items))); ax.set_xticklabels([c.replace("R_", "R$_{") + ("}$" if c.startswith("R_") else "") for c, _ in items], rotation=60, fontsize=7)
    ax.set_xlim(-0.6, len(items) - 0.4); ax.set_ylim(0.77, 0.87); ax.grid(axis="y", alpha=0.3); ax.set_ylabel("cross-dataset AUC", fontsize=8); ax.tick_params(axis="y", labelsize=7)
    fig.savefig(out, bbox_inches="tight"); plt.close(fig)


if __name__ == "__main__":
    a = sys.argv[1:]
    tf = a[0] if len(a) > 0 else here / "data/tfidf_pairwise_auc_change.csv"
    bert = a[1] if len(a) > 1 else here / "data/bert_pairwise_auc_change_5seeds.csv"
    cond = a[2] if len(a) > 2 else here / "data/tfidf_conditions.csv"
    (here / "figs").mkdir(exist_ok=True)
    fig_heatmap(tf, bert, here / "figs/fig_heatmap.pdf")
    fig_gap(cond, here / "figs/fig_gap.pdf")
    bc = a[3] if len(a) > 3 else here / "data/bert_conditions_5seeds.csv"
    fig_bert_controls(bc, here / "figs/fig_bert_controls.pdf")
    print("wrote figs/fig_heatmap.pdf, figs/fig_gap.pdf and figs/fig_bert_controls.pdf")

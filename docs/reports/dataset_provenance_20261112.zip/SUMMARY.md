# Current analysis-input audit

Rows: 61197
SHA-256: 29e96d7b7fe60a94a2652c704f2bd4be9b5bb7e45f540eabeb19320276788ab5

Labels: 0 = real; 1 = fake (source labels).

| Corpus | Real (0) | Fake (1) | Invalid/missing |
|---|---:|---:|---:|
| ISOT | 20923 | 17107 | 0 |
| McIntire | 2964 | 3041 | 0 |
| WELFake_residual | 10427 | 6735 | 0 |

Byte identity comparisons:
- archive/freeze_validation_intermediate/MANIFEST.json: match (rows: match; bytes: match)
- freeze/MANIFEST.json: match (rows: match; bytes: match)

Count consistency:
- manuscript_and_README: match; total delta +0.
- historical_primary_dry_run: mismatch; total delta +1.

Data checks: passed
See audit.json for missing fields, duplicate/conflicting identifiers and cluster summaries.

Construction reproduction: not performed by this audit command.

Byte-hash agreement establishes file identity only.
Counts and cluster summaries do not independently verify overlap or article veracity.
Construction reproduction requires original sources, rules and environment.
Cluster IDs are inspected as recorded; clusters are not recomputed.
Record totals after a parse error are partial.
